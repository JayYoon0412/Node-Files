import { Controller, Get, Req, Res, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AuthService } from './auth.service';
import { Request, Response } from 'express';
import { User } from '../users/entities/user.entity';
import { UserService } from '../users/user.service';

interface IOAuthUser {
  user: Pick<User, 'userNumber' | 'password' | 'name'>;
}

@Controller()
export class AuthController {
  //구글로 로그인 진행. 외부 API는 거의 REST형식

  constructor(
    private readonly userService: UserService,
    private readonly authService: AuthService,
  ) {}

  @Get('/login/google')
  @UseGuards(AuthGuard('google'))
  async loginGoogle(@Req() req: Request & IOAuthUser, @Res() res: Response) {
    console.log('authenticated --google');
    let userFound = await this.userService.findUser({
      userNumber: req.user.userNumber,
    });
    if (!userFound)
      userFound = await this.userService.create({
        userInput: {
          userNumber: req.user.userNumber,
          name: req.user.name,
          password: req.user.password,
        },
      });
    console.log(userFound);
    await this.authService.setRefreshToken({ userFound, res });
    res.redirect(
      'http://localhost:5500/main-project/frontend/login/index.html',
    );
    return await this.authService.generateToken({ userFound });
  }
}
