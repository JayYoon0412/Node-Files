import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-google-oauth20';

export class JwtGoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor() {
    super({
      clientID:
        '930240198047-5j9msmba4un62fmbih1c2h954qq9a28h.apps.googleusercontent.com',
      clientSecret: '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',
      callbackURL: 'http://localhost:3000/login/google',
      scope: ['profile'],
    });
  }
  async validate(accessToken, refreshToken, profile) {
    console.log(profile);
    return {
      userNumber: profile.id,
      name: profile.displayName,
      password: '1234',
    };
  }
}
